class CfgPatches
{
	class DZ_Worlds_ChernarusPlus_CE
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data"
		};
	};
};
